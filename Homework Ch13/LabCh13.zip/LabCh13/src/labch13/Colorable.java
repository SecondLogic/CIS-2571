/*
 * Amos Cabudol
 * CIS 2571-004
 * 04/19/2020
 * Homework Ch. 13 – The Colorable Interface
 *
 * This module contains the Colorable interface
 */
package labch13;

public interface Colorable {
    void howToColor();
}
